//
//  NewContactViewController.swift
//  Phone_2.0
//
//  Created by Oleksii Kolakovskyi on 10/24/19.
//  Copyright © 2019 Aleksey. All rights reserved.
//

import Foundation
import UIKit

class NewContactViewController: UIViewController {
    

    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var notesTextField: UITextView!
    
    override func viewDidLoad() {
        
    }
    
    @IBAction func saveNewContactButtonTapped(_ sender: UIButton) {
        _ = ContactsFormat.addNewContact(firstName: nameTextField.text!,
                                    lastName: lastNameTextField.text!,
                                    number: phoneTextField.text!,
                                    photo: nil,
                                    notes: notesTextField.text!)
        print(contacts)
        navigationController?.popViewController(animated: true)
    }
    
    
    
}

